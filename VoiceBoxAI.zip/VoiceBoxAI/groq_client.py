import requests
import json
import re

def generate_blender_code(api_key, history, model_name):
    """
    history: список словарей [{'role': 'user', 'content': '...'}, ...]
    """
    if not api_key:
        print("Groq Error: API key is missing!")
        return None
        
    if not model_name:
        print("Groq Error: Model name is not specified in settings!")
        return None

    url = "https://api.groq.com/openai/v1/chat/completions"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    # СИСТЕМНЫЙ ПРОМПТ: Оптимизирован для цвета и памяти
    system_prompt = (
        "ACT AS A STRICT BLENDER 4.2 PYTHON CODE GENERATOR.\n"
        "TARGET ENVIRONMENT: Blender 4.2 ONLY. Modern bpy API ONLY.\n"
        "OUTPUT RULES:\n"
        "1. OUTPUT RAW PYTHON CODE ONLY. NO MARKDOWN. NO COMMENTS. NO EXPLANATIONS.\n"
        "2. ALWAYS START WITH 'import bpy'.\n"
        "3. NEVER USE deprecated API.\n"
        "4. COLORING RULE: To color an object, always create/use a material AND set 'material.diffuse_color' "
        "(RGBA) so the color is visible in SOLID VIEWPORT MODE. Also set 'Base Color' input in Principled BSDF.\n"
        "5. MEMORY RULE: If the user says 'it', 'this', or 'change', use 'bpy.context.active_object'. "
        "Do not create new meshes if modifying existing ones.\n"
        "6. MATERIAL 4.2: Use 'Principled BSDF' inputs: [0] for Base Color, [20] for Emission Color.\n"
        "7. ALWAYS ensure 'obj.data.materials.append(mat)' if it's a new material."
    )

    # Формируем список сообщений для Groq
    messages = [{"role": "system", "content": system_prompt}]
    
    # Добавляем историю
    messages.extend(history)

    data = {
        "model": model_name,
        "messages": messages,
        "temperature": 0.0,
        "max_tokens": 2048,
        "top_p": 0.1,
        "stream": False
    }

    try:
        response = requests.post(url, headers=headers, json=data, timeout=20)
        
        # ДЕБАГ: Выводим статус в консоль
        print(f"Groq Response Status: {response.status_code}")
        
        if response.status_code != 200: 
            print(f"Groq API Error: {response.status_code} - {response.text}")
            return None
        
        result = response.json()
        code = result['choices'][0]['message']['content'].strip()
        
        # ДЕБАГ: Печатаем чистый ответ от ИИ перед очисткой
        print("--- AI RAW OUTPUT ---")
        print(code)
        print("----------------------")
        
        # Очистка кода от остатков разметки markdown
        code = re.sub(r'```(?:python|py)?|```', '', code).strip()
        
        # Обрезаем лишний текст, если ИИ его добавил до импорта
        if "import bpy" in code:
            code = code[code.find("import bpy"):]
        
        # Исправление специфических старых аргументов
        code = code.replace("u_u_segments=", "segments=")
        code = code.replace("v_u_segments=", "ring_count=")
        
        return code
        
    except Exception as e:
        print(f"Groq Connection Error: {e}")
        return None