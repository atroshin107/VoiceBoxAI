import requests
import json
import re

def generate_blender_code(api_key, history, model_name):
    """
    history: список словарей [{'role': 'user', 'content': '...'}, ...]
    """
    if not api_key:
        print("OpenAI Error: API key is missing!")
        return None
    
    # Если в настройках пусто, используем gpt-4o
    selected_model = model_name if model_name else "gpt-4o"
        
    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    system_prompt = (
        "Act as a Blender 4.2+ Python API Specialist. Output ONLY raw code.\n"
        "STRICT RULES:\n"
        "1. No markdown, no comments. Start with 'import bpy'.\n"
        "2. RENDER: Use 'BLENDER_EEVEE_NEXT'; scene.eevee.use_raytracing = True.\n"
        "3. BSDF 2.0: Access by index: [0]=BaseColor, [1]=Metallic, [2]=Roughness, [15]=IOR, [20]=EmissionColor.\n"
        "4. VECTORS: All vector inputs (Scale, Offset, Rotation) MUST be 3-element tuples.\n"
        "5. CONTEXT: You have access to the conversation history. If the user asks to 'change', 'color' or 'move' "
        "something previously created, write code that selects and modifies those existing objects."
    )

    # Собираем сообщения: Система + вся история
    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(history)

    data = {
        "model": selected_model,
        "messages": messages,
        "temperature": 0.0
    }

    try:
        r = requests.post(url, headers=headers, json=data, timeout=20)
        if r.status_code != 200:
            print(f"OpenAI API Error: {r.status_code} - {r.text}")
            return None
            
        res = r.json()
        if 'choices' in res:
            code = res['choices'][0]['message']['content'].strip()
            
            # Очистка от маркдауна (на случай если GPT-4o проигнорирует инструкцию)
            code = re.sub(r'```(?:python|py)?|```', '', code).strip()
            
            # Гарантируем начало с импорта
            if "import bpy" in code:
                code = code[code.find("import bpy"):]
                
            return code
        return None
    except Exception as e:
        print(f"OpenAI Exception: {e}")
        return None