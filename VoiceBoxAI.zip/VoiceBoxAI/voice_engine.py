import os
import json
import queue
import sys

addon_dir = os.path.dirname(__file__)
libs_path = os.path.join(addon_dir, "libs")
if libs_path not in sys.path: 
    sys.path.insert(0, libs_path)

if sys.platform == 'win32' and hasattr(os, 'add_dll_directory'):
    try: os.add_dll_directory(libs_path)
    except: pass

import sounddevice as sd
from vosk import Model, KaldiRecognizer

q = queue.Queue()
_model = None
_rec = None
_stream = None
_recording_active = False
_accumulated_text = ""

def load_model():
    global _model, _rec, _stream
    if _model is not None: return True
    
    model_path = os.path.join(addon_dir, "vosk_model_en")
    if not os.path.exists(model_path):
        model_path = os.path.join(addon_dir, "vosk_model", "vosk_model_en")
    
    try:
        _model = Model(model_path)
        _rec = KaldiRecognizer(_model, 16000)
        _stream = sd.RawInputStream(samplerate=16000, blocksize=4000, 
                                    dtype='int16', channels=1, 
                                    callback=lambda indata, frames, time, status: q.put(bytes(indata)))
        _stream.start()
        return True
    except Exception as e:
        print(f"VoxBox Load Error: {e}")
        return False

def set_recording_state(state):
    global _recording_active, _accumulated_text, _rec
    if state:
        # КЛЮЧЕВОЙ МОМЕНТ: Чистим очередь перед записью, чтобы не было "the the" из прошлого
        while not q.empty():
            q.get()
        _accumulated_text = ""
        _rec.Reset()
    _recording_active = state

def update():
    global _rec, _accumulated_text, _recording_active
    if not _rec: return

    while not q.empty():
        data = q.get()
        if _recording_active:
            if _rec.AcceptWaveform(data):
                res = json.loads(_rec.Result())
                _accumulated_text += " " + res.get("text", "")

def get_final_text():
    global _rec, _accumulated_text
    final_res = json.loads(_rec.FinalResult())
    full_text = (_accumulated_text + " " + final_res.get("text", "")).strip()
    
    
    blacklist = ["the", "it", "uh", "um", "a"]
    words = [w for w in full_text.split() if w not in blacklist]
    
    if len(words) == 0: return None
    return " ".join(words)