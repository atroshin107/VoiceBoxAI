import requests
import json
import re

def generate_blender_code(api_key, history, model_name):
    """
    history: список словарей [{'role': 'user', 'content': '...'}, ...]
    """
    if not api_key:
        print("VoiceBox Error: API key is missing!")
        return None

    # Настройка модели
    selected_model = model_name if model_name else "gemma-3-27b-it"
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{selected_model}:generateContent?key={api_key}"
    
    system_prompt = (
        "ACT AS A STRICT BLENDER 4.2 PYTHON CODE GENERATOR.\n"
        "TARGET ENVIRONMENT: Blender 4.2 ONLY. Modern bpy API ONLY.\n"
        "OUTPUT RULES:\n"
        "1. OUTPUT RAW PYTHON CODE ONLY. NO MARKDOWN. NO COMMENTS. NO EXPLANATIONS.\n"
        "2. ALWAYS START WITH 'import bpy'.\n"
        "3. NEVER USE deprecated API (no lamp_add, no layers, no radius for cubes).\n"
        "4. DO NOT USE bpy.ops.object.mode_set unless absolutely necessary.\n"
        "5. USE bpy.context.view_layer.objects.active for setting active objects.\n"
        "6. MATERIAL 4.2: Use 'Principled BSDF' inputs: [0] for Base Color, [20] for Emission Color, [21] for Emission Strength.\n"
        "7. GEOMETRY NODES: Use 'group.interface.new_socket' for inputs/outputs (Blender 4.0+).\n"
        "8. IF CONTEXT IS CLEAR, MODIFY PREVIOUSLY CREATED OBJECTS FROM HISTORY.\n"
        "9. ANIMATION RULES (MANDATORY WHEN ANIMATING):\n"
        "10. ALWAYS use bpy.context.scene.frame_set(frame_number) before inserting keyframes.\n"
        "11. AFTER changing any animatable value, ALWAYS call keyframe_insert with FULL data_path.\n"
        "12. COLOR ANIMATION TEMPLATE (Blender 4.2 NODES):\n"
        "13. Access BSDF via mat.node_tree.nodes['Principled BSDF'].\n"
        "14. Animate color using:\n"
        "mat.node_tree.nodes['Principled BSDF'].inputs[0].keyframe_insert(data_path='default_value')\n"
        "15. WITHOUT keyframe_insert THE TASK IS CONSIDERED FAILED.\n"
    )

    # Превращаем нашу историю в формат Gemini (user/model)
    gemini_contents = []
    
    # Сначала вставляем системную инструкцию как ввод от пользователя (в Gemini v1beta это надежнее)
    gemini_contents.append({
        "role": "user",
        "parts": [{"text": f"SYSTEM INSTRUCTIONS: {system_prompt}\n\nUnderstood. Awaiting task."}]
    })
    gemini_contents.append({
        "role": "model",
        "parts": [{"text": "Understood. I will provide only raw Python code for Blender 4.2."}]
    })

    # Добавляем историю из аддона
    for entry in history:
        # Gemini использует 'model' вместо 'assistant'
        role = "model" if entry['role'] == "assistant" else "user"
        gemini_contents.append({
            "role": role,
            "parts": [{"text": entry['content']}]
        })

    payload = {
        "contents": gemini_contents,
        "generationConfig": {
            "temperature": 0.0,
            "maxOutputTokens": 2048,
            "topP": 0.0,
            "topK": 1
        }
    }

    try:
        response = requests.post(
            url, 
            headers={'Content-Type': 'application/json'}, 
            json=payload, 
            timeout=60
        )
        response.raise_for_status()
        data = response.json()
        
        if 'candidates' in data and len(data['candidates']) > 0:
            content = data['candidates'][0]['content']['parts'][0]['text']
            
            # Очистка от маркдауна
            code = content.replace("```python", "").replace("```py", "").replace("```", "").strip()
            
            if "import bpy" in code:
                code = code[code.find("import bpy"):]
            
            return code
        
        print("VoiceBox Gemini: No candidates in response")
        return None

    except Exception as e:
        print(f"VoiceBox Gemini Error: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"Server Response: {e.response.text}")
        return None