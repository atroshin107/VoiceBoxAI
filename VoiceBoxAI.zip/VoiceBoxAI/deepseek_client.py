import requests
import json
import re

def generate_blender_code(api_key, history, model_name):
    """
    history: список словарей [{'role': 'user', 'content': '...'}, ...]
    """
    if not api_key:
        print("DeepSeek Error: API key is missing!")
        return None
        
    if not model_name:
        print("DeepSeek Error: Model name is not specified in settings!")
        return None

    url = "https://api.deepseek.com/chat/completions"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    system_prompt = (
        "ACT AS A BLENDER 4.2.2 COMPILER. STRICT DATA SPECIFICATION. NO DEVIATIONS.\n\n"
        "--- [1] RENDER ENGINE: EEVEE NEXT ---\n"
        "- bpy.context.scene.render.engine = 'BLENDER_EEVEE_NEXT'\n"
        "- bpy.context.scene.eevee.use_raytracing = True\n\n"
        "--- [2] MATERIAL API: PRINCIPLED BSDF 2.0 (INDEX ONLY) ---\n"
        "- [0] Base Color, [1] Metallic, [2] Roughness, [15] Transmission Weight, [20] Emission Color.\n\n"
        "--- [3] GEOMETRY NODES: NODE REGISTRY ---\n"
        "- Use 'group.interface.new_socket' for inputs/outputs.\n"
        "- Nodes: 'GeometryNodeMeshGrid', 'GeometryNodeInstanceOnPoints', 'GeometryNodeSetPosition', 'GeometryNodeTexNoise'.\n\n"
        "--- [4] TYPE SAFETY ---\n"
        "- 'Offset', 'Rotation', 'Scale' MUST be 3-element tuples.\n"
        "- Always use ShaderNodeCombineXYZ when connecting Float to Vector.\n\n"
        "--- [5] ARCHITECTURE & CONTEXT ---\n"
        "- Avoid bpy.ops.* where possible. Use bpy.data and bpy.context.\n"
        "- DO NOT use bpy.ops.object.mode_set. Assume Object Mode.\n\n"
        "--- [6] OUTPUT ---\n"
        "- ONLY RAW PYTHON. START WITH 'import bpy'. NO MARKDOWN. NO COMMENTS.\n\n"
        "--- [7] MEMORY & CONTEXT ---\n"
        "- You will receive a history of commands. If an object was created in a previous turn, MODIFY it instead of creating a new one unless specified."
    )

    # Формируем сообщения: Система + История (в которой уже есть текущий промпт)
    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(history)

    data = {
        "model": model_name,
        "messages": messages,
        "temperature": 0.1
    }
    
    try:
        response = requests.post(url, headers=headers, json=data, timeout=15)
        if response.status_code != 200:
            print(f"DeepSeek API Error: {response.text}")
            return None
            
        result = response.json()
        code = result['choices'][0]['message']['content'].strip()

        # Очистка от маркдауна
        code = re.sub(r'```(?:python|py)?|```', '', code).strip()

        # Гарантируем начало с импорта
        if "import bpy" in code:
            code = code[code.find("import bpy"):]
            
        return code
    except Exception as e:
        print(f"DeepSeek Connection Error: {e}")
        return None