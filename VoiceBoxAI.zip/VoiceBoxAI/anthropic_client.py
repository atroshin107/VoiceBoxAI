import requests
import json
import re

def generate_blender_code(api_key, prompt, model_name, prev_code=None, error_msg=None):
    if not api_key:
        return "print('Anthropic API Key is missing')"
    
    # Если в настройках пусто, используем актуальную модель Claude 3.5 Sonnet
    selected_model = model_name if model_name else "claude-3-5-sonnet-20240620"
        
    url = "https://api.anthropic.com/v1/messages"
    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json"
    }
    
    # Системные инструкции для Claude
    system_prompt = (
        "Act as a Blender 4.2+ Python API Specialist. Output ONLY raw code.\n"
        "STRICT RULES:\n"
        "1. No markdown, no preamble. Start with 'import bpy'.\n"
        "2. RENDER: Use 'BLENDER_EEVEE_NEXT'; scene.eevee.use_raytracing = True.\n"
        "3. BSDF 2.0: Access by index: [0]=BaseColor, [2]=Roughness, [15]=IOR, [17]=TransmissionWeight.\n"
        "4. VECTORS: All vector inputs (Scale, Offset, Rotation) MUST be tuples (x,y,z).\n"
    )

    user_content = f"Task: {prompt}"
    if prev_code and error_msg:
        user_content = (
            f"FIX THIS CODE FOR BLENDER 4.2:\n{prev_code}\n"
            f"ERROR: {error_msg}\n"
            f"REWRITE ENTIRE SCRIPT FOR: {prompt}"
        )

    data = {
        "model": selected_model,
        "max_tokens": 2048,
        "system": system_prompt,
        "messages": [
            {"role": "user", "content": user_content}
        ],
        "temperature": 0.0
    }

    try:
        r = requests.post(url, headers=headers, json=data, timeout=25)
        if r.status_code != 200:
            print(f"Anthropic API Error: {r.status_code} - {r.text}")
            return None
            
        res = r.json()
        if 'content' in res:
            code = res['content'][0]['text'].strip()
            # Очистка от markdown
            code = re.sub(r'```(?:python|py)?|```', '', code).strip()
            if "import bpy" in code:
                code = code[code.find("import bpy"):]
            return code
        return None
    except Exception as e:
        print(f"Anthropic Exception: {e}")
        return None