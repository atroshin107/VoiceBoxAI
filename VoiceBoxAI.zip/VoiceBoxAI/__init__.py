import bpy
import math
import time
import requests
import threading
import re
import json
from . import voice_engine
from . import gemini_client
from . import groq_client
from . import deepseek_client
from . import openai_client
from . import anthropic_client

bl_info = {
    "name": "VoiceBox AI",
    "version": (2, 1, 12),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > VoiceBox AI",
    "description": "VoiceBox AI - Original UI Format with Delta Fix",
    "category": "Interface",
}

# --- КОНСТАНТЫ ---
AI_HISTORY = [] 
addon_keymaps = []

def update_log(text):
    log_name = "VoiceBox_Log"
    if log_name not in bpy.data.texts:
        bpy.data.texts.new(log_name)
    txt = bpy.data.texts[log_name]
    timestamp = time.strftime('%H:%M:%S')
    txt.write(f"[{timestamp}] {text}\n")
    for area in bpy.context.screen.areas:
        area.tag_redraw()

# --- ПРОВЕРКА КЛЮЧА В ЛЮБОЙ СТРУКТУРЕ (ТВОЙ ОРИГИНАЛ) ---
def find_key_recursive(obj, target_key):
    """Ищет строку target_key в любых вложенных списках и словарях JSON-ответа"""
    if isinstance(obj, str):
        return target_key.lower() == obj.strip().lower()
    elif isinstance(obj, list):
        for item in obj:
            if find_key_recursive(item, target_key):
                return True
    elif isinstance(obj, dict):
        for val in obj.values():
            if find_key_recursive(val, target_key):
                return True
    return False

# --- PREFERENCES ---

class VoiceBoxPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__
    
    is_activated: bpy.props.BoolProperty(name="Is Activated", default=False)
    license_key: bpy.props.StringProperty(name="License Key", subtype='PASSWORD')
    
    ai_service: bpy.props.EnumProperty(
        name="AI Service",
        items=[
            ('GEMINI', "Google Gemini", ""), 
            ('GROQ', "Groq Cloud", ""),
            ('OPENAI', "OpenAI", ""),
            ('DEEPSEEK', "DeepSeek", ""),
            ('ANTHROPIC', "Anthropic", "")
        ],
        default='GEMINI'
    )
    
    gemini_api_key: bpy.props.StringProperty(name="Gemini API Key", subtype='PASSWORD')
    groq_api_key: bpy.props.StringProperty(name="Groq API Key", subtype='PASSWORD')
    openai_api_key: bpy.props.StringProperty(name="OpenAI API Key", subtype='PASSWORD')
    deepseek_api_key: bpy.props.StringProperty(name="DeepSeek API Key", subtype='PASSWORD')
    anthropic_api_key: bpy.props.StringProperty(name="Anthropic API Key", subtype='PASSWORD')
    
    # Поля выбора моделей (Добавлено к твоему коду)
    gemini_model: bpy.props.StringProperty(name="Model", default="gemma-3-27b-it")
    groq_model: bpy.props.StringProperty(name="Model", default="llama-3.3-70b-versatile")
    openai_model: bpy.props.StringProperty(name="Model", default="gpt-4o")
    deepseek_model: bpy.props.StringProperty(name="Model", default="deepseek-chat")
    anthropic_model: bpy.props.StringProperty(name="Model", default="claude-3-5-sonnet-20240620")

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Activation", icon='KEY_HLT')
        row = box.row(align=True)
        row.prop(self, "license_key", text="License")
        
        if self.is_activated:
            row.label(text="", icon='CHECKMARK')
        
        box.operator("voicebox.verify_license", icon='FILE_TICK')
        
        if self.is_activated:
            box_ai = layout.box()
            box_ai.label(text="AI Configuration", icon='NODE_MATERIAL')
            box_ai.prop(self, "ai_service", text="Service")
            
            if self.ai_service == 'GEMINI':
                box_ai.prop(self, "gemini_api_key")
                box_ai.prop(self, "gemini_model")
            elif self.ai_service == 'GROQ': 
                box_ai.prop(self, "groq_api_key")
                box_ai.prop(self, "groq_model")
            elif self.ai_service == 'OPENAI': 
                box_ai.prop(self, "openai_api_key")
                box_ai.prop(self, "openai_model")
            elif self.ai_service == 'DEEPSEEK': 
                box_ai.prop(self, "deepseek_api_key")
                box_ai.prop(self, "deepseek_model")
            elif self.ai_service == 'ANTHROPIC': 
                box_ai.prop(self, "anthropic_api_key")
                box_ai.prop(self, "anthropic_model")

# --- AI CORE ---

def clean_and_fix_python(code):
    if not code: return None
    code = re.sub(r'```(?:python|py)?', '', code)
    code = code.replace('```', '').strip()
    if "import bpy" in code:
        code = code[code.find("import bpy"):]
    return code.strip()

def run_ai_processing(context, prompt):
    global AI_HISTORY
    prefs = context.preferences.addons[__package__].preferences
    update_log(f"USER: {prompt}")

    system_instruction = (
        "You are a Blender Python expert. Context is provided from previous turns. "
        "IMPORTANT: Do not recreate objects that already exist in the scene. Use existing objects. "
        "Provide ONLY the code for the requested change or addition. Use Principled BSDF."
    )

    messages = [{"role": "system", "content": system_instruction}]
    for msg in AI_HISTORY: messages.append(msg)
    messages.append({"role": "user", "content": prompt})

    def bg_task():
        try:
            srv = prefs.ai_service
            code = None
            if srv == 'GEMINI': 
                code = gemini_client.generate_blender_code(prefs.gemini_api_key, messages, prefs.gemini_model)
            elif srv == 'GROQ': 
                code = groq_client.generate_blender_code(prefs.groq_api_key, messages, prefs.groq_model)
            elif srv == 'OPENAI': 
                code = openai_client.generate_blender_code(prefs.openai_api_key, messages, prefs.openai_model)
            elif srv == 'DEEPSEEK': 
                code = deepseek_client.generate_blender_code(prefs.deepseek_api_key, messages, prefs.deepseek_model)
            elif srv == 'ANTHROPIC': 
                code = anthropic_client.generate_blender_code(prefs.anthropic_api_key, messages, prefs.anthropic_model)
            
            if code:
                final_code = clean_and_fix_python(code)
                AI_HISTORY.append({"role": "user", "content": prompt})
                AI_HISTORY.append({"role": "assistant", "content": final_code})
                if len(AI_HISTORY) > 20: AI_HISTORY.pop(0); AI_HISTORY.pop(0)

                def apply():
                    try:
                        exec(compile(final_code, '<string>', 'exec'), globals())
                        update_log("AI: Done.")
                    except Exception as e:
                        update_log(f"PY ERROR: {str(e)}")
                    return None
                bpy.app.timers.register(apply)
        except Exception as e:
            bpy.app.timers.register(lambda: update_log(f"NET ERROR: {str(e)}"))

    threading.Thread(target=bg_task, daemon=True).start()

# --- OPERATORS ---

class VOICEBOX_OT_verify_license(bpy.types.Operator):
    bl_idname = "voicebox.verify_license"
    bl_label = "Verify License"
    
    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        user_key = prefs.license_key.strip()
        
        # ТВОЙ СЕРВЕР (КЛЮЧИ ТЕПЕРЬ ТАМ)
        AUTH_SERVER_URL = "https://voicebox-auth1.vercel.app/api" 
        
        if not user_key:
            self.report({'ERROR'}, "Please enter the key!")
            return {'CANCELLED'}

        try:
            # Отправляем запрос на Vercel
            # Мы используем метод POST, как прописано в index.py на сервере
            response = requests.post(
                AUTH_SERVER_URL, 
                json={"license_key": user_key}, 
                timeout=25
            )
            
            if response.status_code == 200:
                result = response.json()
                if result.get("activated"):
                    prefs.is_activated = True
                    self.report({'INFO'}, "Successfully activated!")
                    update_log("LICENSE: Active (Verified via Proxy).")
                else:
                    self.report({'ERROR'}, "Invalid License Key.")
            elif response.status_code == 403:
                # Этот статус наш сервер вернет, если ключ не найден в инвойсах
                self.report({'ERROR'}, "Key not found or unpaid.")
            else:
                self.report({'ERROR'}, f"Auth Server Error: {response.status_code}")
                
        except Exception as e:
            self.report({'ERROR'}, f"Connection error: {str(e)}")
            
        return {'FINISHED'}

class VOICEBOX_OT_send_text(bpy.types.Operator):
    bl_idname = "voicebox.send_text"
    bl_label = "SEND REQUEST"
    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        if not prefs.is_activated:
            self.report({'ERROR'}, "Activate license first!")
            return {'CANCELLED'}
        prompt = context.scene.voicebox_text_input
        if prompt:
            run_ai_processing(context, prompt)
            context.scene.voicebox_text_input = ""
        return {'FINISHED'}

class VOICEBOX_OT_clear_history(bpy.types.Operator):
    bl_idname = "voicebox.clear_history"
    bl_label = "Clear Memory"
    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        if not prefs.is_activated:
            self.report({'ERROR'}, "Activate license first!")
            return {'CANCELLED'}
        global AI_HISTORY
        AI_HISTORY.clear()
        update_log("MEMORY: Cleared.")
        return {'FINISHED'}

class VOICEBOX_OT_init_engine(bpy.types.Operator):
    bl_idname = "voicebox.init_engine"
    bl_label = "Load Voice Model"
    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        if not prefs.is_activated:
            self.report({'ERROR'}, "Activate license first!")
            return {'CANCELLED'}
        if voice_engine.load_model():
            if not bpy.app.timers.is_registered(voicebox_timer_update):
                bpy.app.timers.register(voicebox_timer_update)
            context.scene.voicebox_ready = True
            update_log("ENGINE: Ready.")
            return {'FINISHED'}
        return {'CANCELLED'}

class VOICEBOX_OT_record_command(bpy.types.Operator):
    bl_idname = "voicebox.record_command"
    bl_label = "Voice Record"
    def modal(self, context, event):
        if event.type == 'V' and event.value == 'RELEASE':
            voice_engine.set_recording_state(False)
            context.window_manager.voicebox_is_recording = False
            text = voice_engine.get_final_text()
            if text and len(text) > 1: run_ai_processing(context, text)
            return {'FINISHED'}
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):
        prefs = context.preferences.addons[__package__].preferences
        if not prefs.is_activated:
            self.report({'ERROR'}, "Activate license first!")
            return {'CANCELLED'}
        if not context.scene.voicebox_ready: return {'CANCELLED'}
        voice_engine.set_recording_state(True)
        context.window_manager.voicebox_is_recording = True
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

# --- UI PANEL ---

class VOICEBOX_PT_panel(bpy.types.Panel):
    bl_label = "VoiceBox AI"; bl_idname = "VOICEBOX_PT_panel"
    bl_space_type = 'VIEW_3D'; bl_region_type = 'UI'; bl_category = 'VoiceBox'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        wm = context.window_manager
        prefs = context.preferences.addons[__package__].preferences
        
        if not prefs.is_activated:
            layout.label(text="Please Activate in Preferences", icon='ERROR')
            return

        input_box = layout.box()
        col = input_box.column(align=True)
        col.prop(scene, "voicebox_text_input", text="", placeholder="Type command...")
        col.separator()
        col.operator("voicebox.send_text", text="SEND REQUEST", icon='PLAY')

        vbox = layout.box()
        if not scene.voicebox_ready:
            vbox.operator("voicebox.init_engine", icon='IMPORT', text="Load Voice Model")
        else:
            col_v = vbox.column()
            col_v.scale_y = 1.4
            is_rec = wm.voicebox_is_recording
            col_v.operator("voicebox.record_command", 
                         text="LISTENING..." if is_rec else "HOLD 'V' TO SPEAK", 
                         icon='REC' if is_rec else 'SPEAKER', 
                         depress=is_rec)

        inf = layout.box()
        col_inf = inf.column(align=True)
        col_inf.label(text=f"Service: {prefs.ai_service}", icon='WORLD')
        
        row_mem = col_inf.row(align=True)
        cycles = len(AI_HISTORY) // 2
        row_mem.label(text=f"Memory: {cycles}/10 cycles", icon='MEMORY')
        row_mem.operator("voicebox.clear_history", text="", icon='TRASH')

# --- REGISTRATION ---

def voicebox_timer_update():
    voice_engine.update()
    return 0.01

classes = (
    VoiceBoxPreferences,
    VOICEBOX_OT_verify_license,
    VOICEBOX_OT_init_engine,
    VOICEBOX_OT_clear_history,
    VOICEBOX_OT_send_text,
    VOICEBOX_OT_record_command,
    VOICEBOX_PT_panel,
)

def register():
    for cls in classes: bpy.utils.register_class(cls)
    bpy.types.Scene.voicebox_ready = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.voicebox_text_input = bpy.props.StringProperty(name="Command")
    bpy.types.WindowManager.voicebox_is_recording = bpy.props.BoolProperty(default=False)
    
    wm = bpy.context.window_manager
    if wm.keyconfigs.addon:
        km = wm.keyconfigs.addon.keymaps.new(name='3D View', space_type='VIEW_3D')
        kmi = km.keymap_items.new("voicebox.record_command", 'V', 'PRESS')
        addon_keymaps.append((km, kmi))

def unregister():
    for km, kmi in addon_keymaps: km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    for cls in reversed(classes): bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()